package com.gugan.credit;
import android.os.Bundle; import android.widget.Button; import android.widget.TextView; import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity { @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); TextView t=findViewById(R.id.title); Button x=findViewById(R.id.financeButton); x.setOnClickListener(v->t.setText("Two Wheeler Finance\nApplication started"));}}
